package com.programming.orderservice.controller;

import com.programming.orderservice.dto.OrderRequest;
import com.programming.orderservice.service.OrderService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.concurrent.ExecutionException;

@RestController
@RequestMapping("/api/order")
@RequiredArgsConstructor
public class OrderController {

    private final OrderService orderService;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public String placeOrder(@RequestBody OrderRequest orderRequest) throws ExecutionException, InterruptedException {
        orderService.placeOrder(orderRequest);
        return "Order placed successfully";
    }
}
